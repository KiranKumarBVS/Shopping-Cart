import React from "react";
import { BrowserRouter, Route, Link } from "react-router-dom";
import { useSelector } from "react-redux";
import "./App.css";
import "./styles.css"
import HomeScreen from "./screens/HomeScreen";
import ProductScreen from "./screens/ProductScreen1";
import CartScreen from "./screens/CartScreen";
import SigninScreen from "./screens/SigninScreen";
import RegisterScreen from "./screens/RegisterScreen";
import ProductsScreen from "./screens/ProductsScreen";
import ShippingScreen from "./screens/ShippingScreen";
import PaymentScreen from "./screens/PaymentScreen";
import PlaceOrderScreen from "./screens/PlaceOrderScreen";
import OrderScreen from "./screens/OrderScreen";
import ProfileScreen from "./screens/ProfileScreen";
import OrdersScreen from "./screens/OrdersScreen";
import CreateAdminScreen from "./screens/CreateAdminScreen";
import AllAdminsScreen from "./screens/AllAdminsScreen";
import AllUsersScreen from "./screens/AllUsersScreen";
import Footer from "./screens/_footer/Footer";
import Header from "./screens/_homepage/Header";

function App() {
  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo } = userSignin;

  return (
    <BrowserRouter>
      <div className="grid-container">
        <Header />
        <main className="main">
          <div className="content">
            <Route path="/" exact={true} component={HomeScreen} />
            <Route path="/category/:id" component={HomeScreen} />
            <Route path="/signin" component={SigninScreen} />
            <Route path="/register" component={RegisterScreen} />
            <Route path="/product/:id" component={ProductScreen} />
            <Route path="/placeorder" component={PlaceOrderScreen} />
            <Route path="/profile" component={ProfileScreen} />
            <Route path="/cart/:id?" component={CartScreen} />
            <Route path="/shipping" component={ShippingScreen} />
            <Route path="/orders" component={OrdersScreen} />
            <Route path="/order/:id" component={OrderScreen} />
            <Route path="/payment" component={PaymentScreen} />
            {userInfo && userInfo.isAdmin && (
              <Route path="/products" component={ProductsScreen} />
            )}
            {userInfo && userInfo.isAdmin && userInfo.isSuperAdmin && (
              <Route path="/createAdmin" component={CreateAdminScreen} />
            )}
            {userInfo && userInfo.isAdmin && userInfo.isSuperAdmin && (
              <Route path="/allAdmins" component={AllAdminsScreen} />
            )}
            {userInfo && userInfo.isAdmin && userInfo.isSuperAdmin && (
              <Route path="/allUsers" component={AllUsersScreen} />
            )}
          </div>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
}

export default App;
