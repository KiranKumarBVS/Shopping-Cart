import React from "react";

function Banner(props) {
    const styles = {
        backgroundImage: `url(${props.url})`,
        backgroundColor: `${props.bcolor !== "" && props.bcolor ? props.bcolor : 'black'}`,
        backgroundSize: 'cover',
        color:`${props.color !== "" && props.color ? props.color : 'white'}`,
        height:`${props.height !== "" && props.height ? props.height : '260px'}`
    };
    return (
        <div className="banner-image" style={styles}>
            <div className="banner-image-text">
                <h1 className="banner-image-text-head">{props.title}</h1>
                <h3>{props.desc}</h3>
            </div>
        </div>
    );
}

export default Banner;