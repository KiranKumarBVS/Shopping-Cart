import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  saveProduct,
  listProducts,
  deleteProdcut,
} from "../actions/productActions";

function ProductsScreen(props) {
  const [modalVisible, setModalVisible] = useState(false);
  const [id, setId] = useState("");
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [image, setImage] = useState(null);
  const [brand, setBrand] = useState("");
  const [category, setCategory] = useState("");
  const [countInStock, setCountInStock] = useState("");
  const [description, setDescription] = useState("");
  const [createdby, setCreatedBy] = useState("");
  const [isverified, setVerified] = useState(false);

  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo } = userSignin;

  const productList = useSelector((state) => state.productList);
  const { loading, products, error } = productList;
  console.log("lsddsfsd",products)
  // const [isverified, setVerified] = useState(productList.products);

  const productSave = useSelector((state) => state.productSave);
  const {
    loading: loadingSave,
    success: successSave,
    error: errorSave,
  } = productSave;

  const productDelete = useSelector((state) => state.productDelete);
  const {
    loading: loadingDelete,
    success: successDelete,
    error: errorDelete,
  } = productDelete;
  const dispatch = useDispatch();

  useEffect(() => {
    // setVerified(products);
    if (successSave) {
      setModalVisible(false);
    }
    dispatch(listProducts());
    return () => {
      //
    };
  }, [successSave, successDelete, isverified]);

  const openModal = (product) => {
    setModalVisible(true);
    setId(product._id);
    setName(product.name);
    setPrice(product.price);
    setDescription(product.description);
    setImage(product.image);
    setBrand(product.brand);
    setCategory(product.category);
    setCountInStock(product.countInStock);
    setCreatedBy(product.createdby);
  };
  const submitHandler = (e) => {
    e.preventDefault();
    const data = new FormData();
    data.set("_id", id);
    data.set("name", name);
    data.set("price", price);
    data.set("brand", brand);
    data.set("category", category);
    data.set("countInStock", countInStock);
    data.set("description", description);
    data.set("image", image);
    data.set("createdby", createdby);
    dispatch(saveProduct(id, data));
  };
  const deleteHandler = (product) => {
    dispatch(deleteProdcut(product._id));
  };
  const onChangeHandler = (event) => {
    setImage(event.target.files[0]);
    console.log(event.target.files[0]);
  };
  const approveHandler = (product) => {};
  return (
    <div className="content content-margined">
      <div className="product-header">
        <h3>Products</h3>
        <button className="button primary" onClick={() => openModal({})}>
          Create Product
        </button>
      </div>
      {modalVisible && (
        <div className="form">
          <form onSubmit={submitHandler}>
            <ul className="form-container">
              <li>
                <h2>Create Product</h2>
              </li>
              <li>
                {loadingSave && <div>Loading...</div>}
                {errorSave && <div>{errorSave}</div>}
              </li>

              <li>
                <label htmlFor="name">Name</label>
                <input
                  type="text"
                  name="name"
                  value={name}
                  id="name"
                  onChange={(e) => setName(e.target.value)}
                ></input>
              </li>
              <li>
                <label htmlFor="price">Price</label>
                <input
                  type="text"
                  name="price"
                  value={price}
                  id="price"
                  onChange={(e) => setPrice(e.target.value)}
                ></input>
              </li>
              <li>
                <label htmlFor="image">Image</label>
                <input type="file" name="file" onChange={onChangeHandler} />
              </li>
              <li>
                <label htmlFor="brand">Brand</label>
                <input
                  type="text"
                  name="brand"
                  value={brand}
                  id="brand"
                  onChange={(e) => setBrand(e.target.value)}
                ></input>
              </li>
              <li>
                <label htmlFor="countInStock">CountInStock</label>
                <input
                  type="text"
                  name="countInStock"
                  value={countInStock}
                  id="countInStock"
                  onChange={(e) => setCountInStock(e.target.value)}
                ></input>
              </li>
              <li>
                <label htmlFor="category">Category</label>
                <select
                  className="category"
                  type="text"
                  name="category"
                  value={category}
                  id="category"
                  onChange={(e) => setCategory(e.target.value)}
                >
                  <option value="" selected>----Please Select----</option>
                  <option value="Pants">Pants</option>
                  <option value="Shirts">Shirts</option>
                  <option value="Sarees">Sarees</option>
                  <option value="Mobiles">Mobiles</option>
                </select>
              </li>
              <li>
                <label htmlFor="description">Description</label>
                <textarea
                  name="description"
                  value={description}
                  id="description"
                  onChange={(e) => setDescription(e.target.value)}
                ></textarea>
              </li>
              <li>
                <label htmlFor="createdby">Created By</label>
                <input
                  type="text"
                  name="createdby"
                  value={userInfo.name}
                  id="createdby"
                  onChange={(e) => setCreatedBy(e.target.value)}
                   disabled="disabled"
                ></input>
              </li>
              <li>
                <button type="submit" className="button primary">
                  {id ? "Update" : "Create"}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setModalVisible(false)}
                  className="button secondary"
                >
                  Back
                </button>
              </li>
            </ul>
          </form>
        </div>
      )}

      <div className="product-list">
        <table className="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Price</th>
              <th>Category</th>
              <th>Brand</th>
              <th>Stocks</th>
              <th>createdBy</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {products
              .filter(
                (products) =>
                  products.createdby === userInfo.name ||
                  userInfo.isSuperAdmin === true
              )
              .map((product) => (
                <tr key={product._id}>
                  <td>{product._id}</td>
                  <td>{product.name}</td>
                  <td>{product.price}</td>
                  <td>{product.category}</td>
                  <td>{product.brand}</td>
                  <td>{product.countInStock}</td>
                  <td>{product.createdby}</td>
                  {userInfo && userInfo.isAdmin && (
                    <>
                      <td>
                        <button
                          className="button"
                          onClick={() => openModal(product)}
                        >
                          Edit                       
                        </button>
                        {" "}
                        <button
                          className="button"
                          onClick={() => deleteHandler(product)}
                        >
                          Delete                       
                        </button>
                      </td>
                      <td>
                        <button
                          className="button"
                          onClick={() => openModal(product)}
                        >
                          Publish
                        </button>{" "}
                      </td>{" "}
                    </>
                  )}
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
export default ProductsScreen;
