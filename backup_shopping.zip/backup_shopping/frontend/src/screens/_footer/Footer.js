import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faLinkedin,
  faFacebook,
  faTwitter,
  faInstagram,
} from "@fortawesome/free-brands-svg-icons";

export default function Footer() {
  const Thisyear = new Date().getFullYear();
  return (
    <React.Fragment>
      <footer className="footer">
        <div className="links">
          <ul>
            <h5>Links</h5>
            <li>About Us</li>
            <li>Contact Us</li>
          </ul>
        </div>
        <div className="text">
          &copy; 2019 - {Thisyear}. All right reserved by J&J Pharma Digital
          Team.
        </div>
        <div className="social">
          <a
            href="https://www.facebook.com"
            target="_blank"
            className="facebook"
          >
            <FontAwesomeIcon icon={faFacebook} size="2x" />
          </a>
          <a href="https://www.twitter.com" target="_blank" className="twitter">
            <FontAwesomeIcon icon={faTwitter} size="2x" />
          </a>
          <a
            href="https://www.instagram.com"
            target="_blank"
            className="instagram"
          >
            <FontAwesomeIcon icon={faInstagram} size="2x" />
          </a>
          <a
            href="https://www.linkedin.com"
            target="_blank"
            className="linkedin"
          >
            <FontAwesomeIcon icon={faLinkedin} size="2x" />
          </a>
        </div>
      </footer>
    </React.Fragment>
  );
}
