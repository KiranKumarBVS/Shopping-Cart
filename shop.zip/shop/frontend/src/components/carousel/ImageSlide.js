import React from "react";

function ImageSlide(props) {
    const styles = {
        backgroundImage: `url(${props.data.url})`,
        backgroundColor: `${props.data.backcolor !== "" ? props.data.backcolor : 'black'}`,
        backgroundSize: 'cover',
        position: "relative",
    };
    const styles1 = {
        color:`${props.data.color !== "" ? props.data.color : 'white'}`
    };
    return (
        <div className="image-slide" style={styles}>
            <div className="image-text" style={styles1}>
                <h1 className="image-text-head">{props.data.title}</h1>
                <p>{props.data.desc}</p>
            </div>
        </div>
    );
}

export default ImageSlide;