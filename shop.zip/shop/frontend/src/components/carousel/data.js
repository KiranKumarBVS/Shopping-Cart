export default {
    slides:[
        {
            url:"https://rukminim1.flixcart.com/flap/1688/280/image/c2bef673e07b2837.jpg?q=50",
            backcolor:"",
            color:"",
            title:"",
            desc:""
        },
        {
            url:"https://rukminim1.flixcart.com/flap/1688/280/image/7929fe3e4caf5f3b.jpg?q=50",
            backcolor:"",
            color:"",
            title:"",
            desc:""
        },
        {
            url:"",
            backcolor:"",
            color:"",
            title:"Buy 2 & Get 1 Free",
            desc:"Buy any Two Shirt or Pant & Get One Free"
        },
        {
            url:"",
            backcolor:"red",
            color:"",
            title:"FLASH SALE",
            desc:"Upto 60% Off On All Products"
        }
    ]
}