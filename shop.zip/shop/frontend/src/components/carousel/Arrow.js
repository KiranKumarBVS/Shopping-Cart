import React from "react";

function Arrow(props){
    return (<div 
		className={ `slide-arrow ${props.direction}` } 
		onClick={props.clickFunction}>
		<div className={ `${props.direction}-arrow` }>
		{props.glyph}
		</div> 
	</div>);
}

export default Arrow;