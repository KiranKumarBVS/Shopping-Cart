import express from 'express';
import Product from '../models/productModel';
import { isAuth, isAdmin } from '../util';
import multer from 'multer';

const router = express.Router();

const DIR = './public/images';
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, DIR);
  },
  filename: (req, file, cb) => {
    const fileName = (new Date().getTime()) + file.originalname.toLowerCase().split(' ').join('-');
    cb(null, fileName)
  }
});
var upload = multer({
  storage: storage,
  fileFilter: (req, file, cb) => {
    if (file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg") {
      cb(null, true);
    } else {
      cb(null, false);
      return cb(new Error('Only .png, .jpg and .jpeg format allowed!'));
    }
  }
});

router.get("/", async (req, res) => {
  const category = req.query.category ? { category: req.query.category } : {};
  const searchKeyword = req.query.searchKeyword ? {
    name: {
      $regex: req.query.searchKeyword,
      $options: 'i'
    }
  } : {};
  const sortOrder = req.query.sortOrder ?
    (req.query.sortOrder === 'lowest' ? { price: 1 } : { price: -1 })
    :
    { _id: -1 };
  const priceCategory = (price) => {
    if (price === "0-2000") {
      return 1;
    }
    else if (price === "2000-4000") {
      return 2;
    }
    else if (price === "4000-6000") {
      return 3;
    }
    else {
      return 4;
    }
  }
  const priceRange = req.query.priceRange ? { priceRange: priceCategory(req.query.priceRange) } : {};
  //console.log(priceRange);
  const products = await Product.find({ ...category, ...searchKeyword, ...priceRange }).sort(sortOrder);
  res.send(products);
});

router.get("/:id", async (req, res) => {
  const product = await Product.findOne({ _id: req.params.id });
  if (product) {
    res.send(product);
  } else {
    res.status(404).send({ message: "Product Not Found." });
  }
});

router.put("/:id", isAuth, isAdmin,upload.single('image'), async (req, res) => {
  const url = req.protocol + '://' + req.get('host')
  const productId = req.params.id;
  const product = await Product.findById(productId);
  const priceCategory = (price) => {
    if (price >= 0 && price < 2000) {
      return 1;
    }
    else if (price >= 2000 && price < 4000) {
      return 2;
    }
    else if (price >= 4000 && price < 6000) {
      return 3;
    }
    else {
      return 4;
    }
  }
  const priceRange = priceCategory(req.body.price);
  if (product) {
    product.name = req.body.name || product.name;
    product.price = req.body.price || product.price;
    product.image = url + '/public/images/' + req.file.filename || product.image;
    product.brand = req.body.brand || product.brand;
    product.category = req.body.category || product.category;
    product.countInStock = req.body.countInStock || product.countInStock;
    product.priceRange = priceRange || product.priceRange;
    product.description = req.body.description || product.description;
    product.createdby = req.body.createdby || product.createdby;
    const updatedProduct = await product.save();
    if (updatedProduct) {
      return res.status(200).send({ message: 'Product Updated', data: updatedProduct });
    }
  }
  return res.status(500).send({ message: ' Error in Updating Product.' });

});

router.delete("/:id", isAuth, isAdmin, async (req, res) => {
  const deletedProduct = await Product.findById(req.params.id);
  if (deletedProduct) {
    await deletedProduct.remove();
    res.send({ message: "Product Deleted" });
  } else {
    res.send("Error in Deletion.");
  }
});


router.post("/", isAuth, isAdmin, upload.single('image'), async (req, res) => {
  const url = req.protocol + '://' + req.get('host')
  const priceCategory = (price) => {
    if (price >= 0 && price < 2000) {
      return 1;
    }
    else if (price >= 2000 && price < 4000) {
      return 2;
    }
    else if (price >= 4000 && price < 6000) {
      return 3;
    }
    else {
      return 4;
    }
  }
  const priceRange = priceCategory(req.body.price);
  const product = new Product({
    name: req.body.name,
    price: req.body.price,
    image: url + '/public/images/' + req.file.filename,
    brand: req.body.brand,
    category: req.body.category,
    priceRange: priceRange,
    countInStock: req.body.countInStock,
    description: req.body.description,
    rating: req.body.rating,
    numReviews: req.body.numReviews,
    createdby: req.body.createdby,
  });
  const newProduct = await product.save();
  if (newProduct) {
    return res.status(201).send({ message: 'New Product Created', data: newProduct });
  }
  return res.status(500).send({ message: ' Error in Creating Product.' });
})


export default router;