import React from 'react';
import { render } from '@testing-library/react';
import ReactDOM from "react-dom";
import App from './App';
import { shallow } from 'enzyme';
import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { Provider } from 'react-redux'
import { Route } from 'react-router-dom';

configure({ adapter: new Adapter() });


it('it renders Loginscreen without crashing', () => {
  const Provider = document.createElement("Provider");
  ReactDOM.render(<App />, Provider)
})

it("Component Header", () => {
  const wrapper = shallow(
    <App />
  )
  wrapper.find('Header');
})

it("Component renders link to TovRoute", () => {
  const wrapper = shallow(
    <App />
  )
  const TovRoute = wrapper.find('TovRoute');
  expect(TovRoute.prop('path')).toBe('/');
})

it("Component renders link to TovPrivateRoute", () => {
  const wrapper = shallow(
    <App />
  )
  const TovPrivateRoute = wrapper.find('TovPrivateRoute');
  expect(TovPrivateRoute.prop('path')).toBe('/my-tov');
})

it("Component renders link to Not Found Page", () => {
  const wrapper = shallow(
    <App />
  )
  const Route = wrapper.find('Route');
  Route.Notfound = jest.fn();
  expect(Route.Notfound).toBeDefined();
  expect(Route.prop('path')).toBe('*');
})