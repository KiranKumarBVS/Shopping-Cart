import { combineReducers } from 'redux'
import userReducer from './user/userReducer'
import tovReducer from './tov/tovReducer'
import needReducer from './needclarify/needReducer'
import consentReducer from './consent/consentReducer'

const rootReducer = combineReducers({
  user: userReducer,
  tov: tovReducer,
  needclarify : needReducer,
  consent : consentReducer
})

export default rootReducer