import {
  USER_DATA,
  USER_LOGIN_SUCCESS,
  USER_LOGIN_FAILURE,
  USER_LOGOUT
} from './userTypes'
import axios from 'axios'
import qs from 'qs'

export const userGetData = () => {
  return {
    type: USER_DATA
  }
}

const fetchUserdataSuccess = (user) => {
  return {
    type: USER_LOGIN_SUCCESS,
    payload: user
  }
}

export const fetchUserdataFailure = (error) => {
  return {
    type: USER_LOGIN_FAILURE,
    payload: error,
  }
}

export const userLogout = () => {
  return {
    type: USER_LOGOUT
  }
}
var proxyUrl = process.env.REACT_APP_PROXY_API;
export const hcoUserLogin = (hcoid) => {
  return (dispatch) => {
    let targetUrl = process.env.REACT_APP_APIGEE_URL + '/accesstoken';
    const headers = { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' }
    var details = {
      'grant_type': process.env.REACT_APP_GRANT_TYPE,
      'client_id': process.env.REACT_APP_CLIENT_ID,
      'client_secret': process.env.REACT_APP_CLIENT_SECRET,
    };
    axios.post(proxyUrl + targetUrl, qs.stringify(details), { headers: headers })
      .then(response => {
        const access_token = response.data.access_token
        let targetUrl = process.env.REACT_APP_APIGEE_URL + '/tov/hco/' + hcoid + '?apiKey=' + process.env.REACT_APP_CLIENT_ID;
        axios.get(proxyUrl + targetUrl, { headers: { 'authorization': 'Bearer ' + access_token } })
          .then(resp => {
            const profile = resp.data.profile
            if (profile.codsid) {
              let userInfo = {
                type: 'hcouser',
                name: profile.Name,
                address: profile.address,
                province: profile.province,
                city: profile.city,
                postal: profile.postal,
                codsid: profile.codsid,
              }
              dispatch(fetchUserdataSuccess(userInfo))
            }
            else {
              const errorMsg = {
                error: 'Service unavailable! The server is temporarily unable to service your request due to maintenance downtime or capacity problems. Please try again later.',
                type: 'hco'
              }
              dispatch(fetchUserdataFailure(errorMsg))
            }
          })
          .catch(error => {
            const errorMsg = {
              error: 'Service unavailable! The server is temporarily unable to service your request due to maintenance downtime or capacity problems. Please try again later.',
              type: 'hco'
            }
            dispatch(fetchUserdataFailure(errorMsg))
          })
      })
      .catch(error => {
        const errorMsg = {
          error: 'Service is down try after some time',
          type: 'hco'
        }
        dispatch(fetchUserdataFailure(errorMsg))
      })
  }
}

export const hcpUserLogin = (username, password) => {
  return (dispatch) => {
    let targetUrl = process.env.REACT_APP_JANRAIN_URL
    const headers = {
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'authorization': 'Basic M3dneTl6cWNmZnFjczl0dHFuamY1ZHJmc3U2N3lwMmo6cWI4NmFiZ2E0cDZoNGZoMzM3anlucHU0bm4zcnV1Mno=',
    }
    var details = {
      'locale': process.env.REACT_APP_JANRAIN_LOCALE,
      'form': process.env.REACT_APP_JANRAIN_FORM,
      'flow': process.env.REACT_APP_JANRAIN_FLOW,
      'flow_version': process.env.REACT_APP_JANRAIN_FLOW_VERSION,
      'signInEmailAddress': username,
      'client_id': process.env.REACT_APP_JANRAIN_CLIENT_ID,
      'redirect_uri': process.env.REACT_APP_REDIRECT_URI,
      'currentPassword': password,
    };
    axios.post(proxyUrl + targetUrl, qs.stringify(details), { headers: headers })
      .then(response => {
        const valid = response.data.capture_user.validation.status
        if (valid === 'VALID_USER') {
          const profile = response.data.capture_user
          if (profile.CODSID) {
            let userInfo = {
              type: 'hcpuser',
              fname: profile.givenName,
              lname: profile.lastName,
              email: profile.email,
              codsid: profile.CODSID,
              jowaId: profile.JOWAID
            }
            dispatch(fetchUserdataSuccess(userInfo))
          }
        }
        else {
          let error = {
            error: 'User is not valid or account is veriied',
            type: 'hcp'
          }
          dispatch(fetchUserdataFailure(error))
        }
      })
      .catch(error => {
        const errorMsg = {
          error: 'Service is down try after some time',
          type: 'hcp'
        }
        dispatch(fetchUserdataFailure(errorMsg))
      })
  }
}
export const logout = () => {
  return (dispatch) => {
    dispatch(userLogout())
  }
}