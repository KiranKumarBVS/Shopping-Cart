import {
  USER_DATA,
  USER_LOGIN_SUCCESS,
  USER_LOGIN_FAILURE,
  USER_LOGOUT,
} from "./userTypes";
import btoa from "btoa";

const loginfo = sessionStorage.getItem("logInfo")
  ? JSON.parse(atob(sessionStorage.getItem("logInfo")))
  : {};
const initialState = {
  isLogin: !!sessionStorage.getItem("logInfo"),
  userData: loginfo,
  error: "",
  error_type: "",
};

const userReducer = (state = initialState, action) => {
  switch (action.type) {
    case USER_DATA:
      return {
        ...state,
      };
    case USER_LOGIN_SUCCESS:
      let data = btoa(JSON.stringify(action.payload));
      sessionStorage.setItem("logInfo", data);
      return {
        isLogin: true,
        userData: action.payload,
        error: "",
        error_type: "",
      };
    case USER_LOGIN_FAILURE:
      return {
        isLogin: false,
        userData: {},
        error: action.payload.error,
        error_type: action.payload.type,
      };
    case USER_LOGOUT:
      sessionStorage.removeItem("logInfo");
      return {
        isLogin: false,
        userData: {},
        error: "",
        error_type: "",
      };
    default:
      return state;
  }
};

export default userReducer;
