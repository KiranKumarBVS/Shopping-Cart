import {
  TOV_DATA,
  TOV_FETCH_LOAD,
  TOV_FETCH_FAILURE,
  TOV_FETCH_SUCCESS
} from './tovTypes'
import axios from 'axios'
import qs from 'qs'

export const tovData = () => {
  return {
    type: TOV_DATA
  }
}

export const tovDataLoad = () => {
  return {
    type: TOV_FETCH_LOAD
  }
}

const tovDataFetchSuccess = (data) => {
  return {
    type: TOV_FETCH_SUCCESS,
    payload: data
  }
}

const tovDataFetchFailure = (error) => {
  return {
    type: TOV_FETCH_FAILURE,
    payload: error
  }
}
export const fetchTovData = (codsid) => {
  return (dispatch) => {
    let data = {
      'codsid': codsid
    }
    const headers = {
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
    }
    axios.post(process.env.REACT_APP_HPR_API, qs.stringify(data), { headers: headers })
      .then(response => {
        data = JSON.parse(response.data)
        dispatch(processdata(data))
      })
      .catch(error => {
        const errorMsg = 'The Web Server may be down, too busy, or experiencing other problems preventing it from responding to requests. You may wish to try again at a later time.'
        dispatch(tovDataFetchFailure(errorMsg))
      })
  }
}

const processdata = (data) => {
  return (dispatch) => {
    let tov = {}
    if (data.Success) {
      const currentyear = new Date().getFullYear()
      const lastyear = currentyear - 1;
      const twoyear = currentyear - 2;

      tov[currentyear] = {
        total: data.GeneralCustomerInfo.TotalToVThisYear,
        totalffs: data.GeneralCustomerInfo.TotalFfsThisYear,
        totalTa: data.GeneralCustomerInfo.TotalTaThisYear,
        totaledg: data.GeneralCustomerInfo.TotalEdgThisYear,
        totalspo: data.GeneralCustomerInfo.TotalSpoThisYear,
        currency: data.GeneralCustomerInfo.DefaultCurrency,
        events: [],
        nc_events: []
      };

      tov[lastyear] = {
        total: data.GeneralCustomerInfo.TotalToVLastYear,
        totalffs: data.GeneralCustomerInfo.TotalFfsLastYear,
        totalTa: data.GeneralCustomerInfo.TotalTaLastYear,
        totaledg: data.GeneralCustomerInfo.TotalEdgLastYear,
        totalspo: data.GeneralCustomerInfo.TotalSpoLastYear,
        currency: data.GeneralCustomerInfo.DefaultCurrency,
        events: [],
        nc_events: []
      };

      tov[twoyear] = {
        total: data.GeneralCustomerInfo.TotalToVTwoYearsAgo,
        totalffs: data.GeneralCustomerInfo.TotalFfsTwoYearsAgo,
        totalTa: data.GeneralCustomerInfo.TotalTaTwoYearsAgo,
        totaledg: data.GeneralCustomerInfo.TotalEdgTwoYearsAgo,
        totalspo: data.GeneralCustomerInfo.TotalSpoTwoYearsAgo,
        currency: data.GeneralCustomerInfo.DefaultCurrency,
        events: [],
        nc_events: []
      };

      const events = data.Events

      events.forEach((event) => {
        // Current Year
        if (event.Customer.TotalAmountThisYear ||
          event.Customer.FfsAmountThisYear ||
          event.Customer.TravelAmountThisYear ||
          event.Customer.HotelAmountThisYear ||
          event.Customer.MealsAmountThisYear ||
          event.Customer.EdgAmountThisYear ||
          event.Customer.SpoAmountThisYear ||
          event.Customer.RegAmountThisYear ||
          event.Customer.OtherAmountThisYear ||
          event.Customer.ParticipantTaAmountThisYear) {

          tov[currentyear].events.push({
            id: event.ID,
            name: event.Name,
            type: event.Type,
            location: event.Location,
            role: event.Customer.Role,
            country: event.Country,
            startDate: event.StartDate,
            endDate: event.EndDate,
            TotalAmount: event.Customer.TotalAmountThisYear,
            FfsAmount: event.Customer.FfsAmountThisYear,
            TravelAmount: event.Customer.TravelAmountThisYear,
            HotelAmount: event.Customer.HotelAmountThisYear,
            EdgAmount: event.Customer.EdgAmountThisYear,
            MealsAmount: event.Customer.MealsAmountThisYear,
            RegAmount: event.Customer.RegAmountThisYear,
            SpoAmount: event.Customer.SpoAmountThisYear,
            OtherAmount: event.Customer.OtherAmountThisYear,
            ParticipantTaAmount: event.Customer.ParticipantTaAmountThisYear
          })
          tov[currentyear].nc_events.push({
            value: event.Name
          })
        }

        //last Tear
        if (event.Customer.TotalAmountLastYear ||
          event.Customer.FfsAmountLastYear ||
          event.Customer.TravelAmountLastYear ||
          event.Customer.HotelAmountLastYear ||
          event.Customer.MealsAmountLastYear ||
          event.Customer.EdgAmountLastYear ||
          event.Customer.SpoAmountLastYear ||
          event.Customer.RegAmountLastYear ||
          event.Customer.OtherAmountLastYear ||
          event.Customer.ParticipantTaAmountLastYear) {
          tov[lastyear].events.push({
            id: event.ID,
            name: event.Name,
            type: event.Type,
            location: event.Location,
            role: event.Customer.Role,
            country: event.Country,
            startDate: event.StartDate,
            endDate: event.EndDate,
            TotalAmount: event.Customer.TotalAmountLastYear,
            FfsAmount: event.Customer.FfsAmountLastYear,
            TravelAmount: event.Customer.TravelAmountLastYear,
            HotelAmount: event.Customer.HotelAmountLastYear,
            EdgAmount: event.Customer.EdgAmountLastYear,
            MealsAmount: event.Customer.MealsAmountLastYear,
            RegAmount: event.Customer.RegAmountLastYear,
            SpoAmount: event.Customer.SpoAmountLastYear,
            OtherAmount: event.Customer.OtherAmountLastYear,
            ParticipantTaAmount: event.Customer.ParticipantTaAmountLastYear
          })
          tov[lastyear].nc_events.push({
            value: event.Name
          })
        }
        //two years ago
        if (event.Customer.TotalAmountTwoYearsAgo ||
          event.Customer.FfsAmountTwoYearsAgo ||
          event.Customer.TravelAmountTwoYearsAgo ||
          event.Customer.HotelAmountTwoYearsAgo ||
          event.Customer.MealsAmountTwoYearsAgo ||
          event.Customer.EdgAmountTwoYearsAgo ||
          event.Customer.SpoAmountTwoYearsAgo ||
          event.Customer.RegAmountTwoYearsAgo ||
          event.Customer.OtherAmountTwoYearsAgo ||
          event.Customer.ParticipantTaAmountTwoYearsAgo) {
          tov[twoyear].events.push({
            id: event.ID,
            name: event.Name,
            type: event.Type,
            location: event.Location,
            role: event.Customer.Role,
            country: event.Country,
            startDate: event.StartDate,
            endDate: event.EndDate,
            TotalAmount: event.Customer.TotalAmountTwoYearsAgo,
            FfsAmount: event.Customer.FfsAmountTwoYearsAgo,
            TravelAmount: event.Customer.TravelAmountTwoYearsAgo,
            HotelAmount: event.Customer.HotelAmountTwoYearsAgo,
            EdgAmount: event.Customer.EdgAmountTwoYearsAgo,
            MealsAmount: event.Customer.MealsAmountTwoYearsAgo,
            RegAmount: event.Customer.RegAmountTwoYearsAgo,
            SpoAmount: event.Customer.SpoAmountTwoYearsAgo,
            OtherAmount: event.Customer.OtherAmountTwoYearsAgo,
            ParticipantTaAmount: event.Customer.ParticipantTaAmountTwoYearsAgo
          })
          tov[twoyear].nc_events.push({
            value: event.Name
          })
        }
      })
      dispatch(tovDataFetchSuccess(tov))
    }
    else {
      const errorMsg = 'Server is down. Please try after some time'
      dispatch(tovDataFetchFailure(errorMsg))
    }
  }

}