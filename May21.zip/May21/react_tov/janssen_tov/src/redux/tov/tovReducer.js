import { 
  TOV_DATA,
  TOV_FETCH_FAILURE,
  TOV_FETCH_LOAD,
  TOV_FETCH_SUCCESS
 } from './tovTypes'

const initialState = {
  loading: 'true',
  tovdata: {},
  error: ''
}

const tovReducer = (state = initialState, action) => {
  switch(action.type) {
    case TOV_DATA: return {
      ...state,
    }
    case TOV_FETCH_LOAD: return {
      loading: 'true'
    }
    case TOV_FETCH_SUCCESS: return {
      loading: '',
      tovdata: action.payload,
      error: ''
    }
    case TOV_FETCH_FAILURE: return {
      loading: '',
      tovdata: {},
      error: action.payload
    }
    default: return state
  }
}

export default tovReducer