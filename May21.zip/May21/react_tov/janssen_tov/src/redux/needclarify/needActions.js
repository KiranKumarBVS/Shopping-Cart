import { NEED_DATA, NEED_FETCH_SUCCESS, NEED_FETCH_FAILURE } from "./needTypes";
import axios from "axios";
import qs from "qs";

export const needClarifyData = () => {
  return {
    type: NEED_DATA,
  };
};

const fetchNeeddataSuccess = (profile) => {
  return {
    type: NEED_FETCH_SUCCESS,
    payload: profile,
  };
};

export const fetchNeeddataFailure = (error) => {
  return {
    type: NEED_FETCH_FAILURE,
    payload: error,
  };
};

var proxyUrl = process.env.REACT_APP_PROXY_API;

export const needClarifyApi = () => {
  return (dispatch) => {
    let targetUrl = process.env.REACT_APP_APIGEE_URL + "/accesstoken";
    const headers = {
      "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
    };
    var details = {
      grant_type: process.env.REACT_APP_GRANT_TYPE,
      client_id: process.env.REACT_APP_CLIENT_ID,
      client_secret: process.env.REACT_APP_CLIENT_SECRET,
    };
    axios
      .post(proxyUrl + targetUrl, qs.stringify(details), { headers: headers })
      .then((response) => {
        const access_token = response.data.access_token;
        console.log(access_token);
        let targetUrl =
          process.env.REACT_APP_APIGEE_URL +
          "/tov/customerService" +
          "?apiKey=" +
          process.env.REACT_APP_CLIENT_ID;
        const needheaders = {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
          authorization: `Bearer ${access_token}`,
        };
        var details = {
          site: "",
          codsid: "OAE199",
          user_email: "",
          phone: "",
          call_type: "",
          date: "",
          time: "",
          subject: "",
          description: "",
          country: "",
          type: "",
          source_out: "",
        };
        axios
          .post(proxyUrl + targetUrl, qs.stringify(details), {
            headers: needheaders,
          })
          .then((response) => {
            const profile = response.data;
            console.log(response.data);
            dispatch(fetchNeeddataSuccess(profile));
          })
          .catch((error) => {
            const errorMsg = "no data.";
            dispatch(fetchNeeddataFailure(errorMsg));
          });
      });
  };
};
