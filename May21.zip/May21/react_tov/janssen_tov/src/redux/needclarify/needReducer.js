import {
  NEED_DATA,
  NEED_FETCH_LOAD,
  NEED_FETCH_FAILURE,
  NEED_FETCH_SUCCESS,
} from "./needTypes";

const initialState = {
  loading: "true",
  tovdata: {},
  error: "",
};

const needReducer = (state = initialState, action) => {
  switch (action.type) {
    case NEED_DATA:
      return {
        ...state,
      };
    case NEED_FETCH_LOAD:
      return {
        loading: "true",
      };
    case NEED_FETCH_SUCCESS:
      return {
        loading: "",
        needdata: action.payload,
        error: "",
      };
    case NEED_FETCH_FAILURE:
      return {
        loading: "",
        needdata: {},
        error: action.payload,
      };
    default:
      return state;
  }
};

export default needReducer;
