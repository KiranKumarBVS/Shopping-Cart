import { 
    CONSENT_DATA,
    CONSENT_FETCH_FAILURE,
    CONSENT_FETCH_SUCCESS
   } from './consentTypes'
  
  const initialState = {
    loading: 'true',
    consentdata: {},
    error: ''
  }
  
  const consentReducer = (state = initialState, action) => {
    switch(action.type) {
      case CONSENT_DATA: return {
        ...state,
      }
      
      case CONSENT_FETCH_SUCCESS: return {
        loading: '',
        consentdata: action.payload,
        error: ''
      }
      case CONSENT_FETCH_FAILURE: return {
        loading: '',
        consentdata: {},
        error: action.payload
      }
      default: return state
    }
  }
  
  export default consentReducer