import {
  CONSENT_DATA,
  CONSENT_FETCH_SUCCESS,
  CONSENT_FETCH_FAILURE,
} from "./consentTypes";
import axios from "axios";
import qs from "qs";

export const consentGetData = () => {
  return {
    type: CONSENT_DATA,
  };
};

export const fetchConsentdataSuccess = (profile) => {
  return {
    type: CONSENT_FETCH_SUCCESS,
    payload: profile,
  };
};

export const fetchConsentdataFailure = (error) => {
  return {
    type: CONSENT_FETCH_FAILURE,
    payload: error,
  };
};

var proxyUrl = process.env.REACT_APP_PROXY_API;

export const ConsentApi = () => {
  console.log();
  return (dispatch) => {
    let targetUrl = process.env.REACT_APP_APIGEE_URL + "/accesstoken";
    const headers = {
      "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
    };
    var details = {
      grant_type: process.env.REACT_APP_GRANT_TYPE,
      client_id: process.env.REACT_APP_CLIENT_ID,
      client_secret: process.env.REACT_APP_CLIENT_SECRET,
    };
    axios
      .post(proxyUrl + targetUrl, qs.stringify(details), { headers: headers })
      .then((response) => {
        const access_token = response.data.access_token;
        let targetUrl =
          process.env.REACT_APP_APIGEE_URL +
          "/tov/profile/PLB8716?apiKey=" +
          process.env.REACT_APP_CLIENT_ID;

        axios
          .get(proxyUrl + targetUrl, {
            headers: { authorization: "Bearer " + access_token },
          })
          .then((resp) => {
            const profile = resp.data.profile;
            dispatch(fetchConsentdataSuccess(profile));
          })
          .catch((error) => {
            const errorMsg = "No Data.";
            dispatch(fetchConsentdataFailure(errorMsg));
          });
      });
  };
};

export const UpdateConsentApi = (consentdata) => {
  return (dispatch) => {
    let targetUrl = process.env.REACT_APP_APIGEE_URL + "/accesstoken";
    const headers = {
      "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
    };
    var details = {
      grant_type: process.env.REACT_APP_GRANT_TYPE,
      client_id: process.env.REACT_APP_CLIENT_ID,
      client_secret: process.env.REACT_APP_CLIENT_SECRET,
    };
    axios
      .post(proxyUrl + targetUrl, qs.stringify(details), { headers: headers })
      .then((response) => {
        const access_token = response.data.access_token;
        var details = {
          consent: consentdata,
        };
        let targetUrl =
          process.env.REACT_APP_APIGEE_URL +
          "/tov/profile/PLB8716?apiKey=" +
          process.env.REACT_APP_CLIENT_ID;

        axios
          .post(proxyUrl + targetUrl, qs.stringify(details), {
            headers: { authorization: "Bearer " + access_token },
          })
          .then((resp) => {
            const message = resp;
            console.log(message);
            dispatch(fetchConsentdataSuccess(message));
          })
          .catch((error) => {
            const errorMsg = "no data.";
            dispatch(fetchConsentdataFailure(errorMsg));
          });
      });
  };
};
