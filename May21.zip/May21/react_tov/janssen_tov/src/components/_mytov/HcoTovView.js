import React from 'react'
import { useSelector } from 'react-redux'
import EventHco from './EventHco'

function HcoTovView(props) {
  const year = props.year
  const tov = useSelector(state => state.tov)

  const tovdata = tov.tovdata[year]
  const events = tovdata.events

  return (
    <div className="listview">
      <table className="tovtable">
        <tbody>
          <tr className="tovTotalCost">
            <td colSpan="2"></td>
            <td>{tovdata.totaledg} *</td>
            <td colSpan="2"> {tovdata.totalspo} </td>
            <td colSpan="4"></td>
          </tr>
          <tr className="trodd mainHead">
            <td></td>
            <td className="eventHead"></td>
            <td rowSpan="2">Donations and Grants  to HCOs</td>
            <td colSpan="2">Fee for Service and contribution to cost of events</td>
            <td colSpan="4">Event information</td>
          </tr>
          <tr className="treven">
            <td>CURRENCY<span>&nbsp;</span></td>
            <td className="eventHead no-top-border">Event Name</td>
            <td>Sponsorship agreements with HCOs / third parties appointed by HCOs to manage an Event</td>
            <td>Fees</td>
            <td>Location</td>
            <td>Country</td>
            <td>Start Date</td>
            <td>End Date</td>
          </tr>
          {events.map((event, index) => (
            <EventHco event={event} index={index} key={index} />
          ))
          }
        </tbody>
      </table>
    </div>

  )
}

export default HcoTovView
