import React from 'react'

function EventHco(props) {
  const event = props.event
  const classname = props.index % 2 ? 'treven' : 'trodd'

  return (
    <tr className={classname} data-testid="changeClass">
      <td className="nfctd" data-testid="nfctd">Need Clarification</td>
      <td className="eventHead" data-testid="eventName">{event.name}</td>
      <td>{event.EdgAmount}</td>
      <td> {event.SpoAmount} </td>
      <td>{event.FfsAmount}</td>
      <td>{event.location}</td>
      <td>{event.country} </td>
      <td>{event.startDate}</td>
      <td>{event.endDate}</td>
    </tr>
  )
}

export default EventHco
