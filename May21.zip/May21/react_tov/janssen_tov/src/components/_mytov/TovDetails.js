import React from 'react'
import { useSelector } from 'react-redux'
import EventList from './EventList'
import TovEventLink from './TovEventLink'

function TovDetails(props) {
  const tov = useSelector(state => state.tov)
  const user = useSelector(state => state.user)
  const year = props.year
  const tovdata = tov.tovdata[year]
  if (!tovdata || !tovdata.total) {
    return (
      <div className="eventdata">
        <h3 className="noData">No data available</h3>
      </div>
    )
  }
  else {
    let colhead = ''
    let totolCount = ''
    let eventtype = ''
    if (user.userData.type === "hcouser") {
      colhead = 'Fee for Service and contribution to cost of events'
      totolCount = tovdata.totalspo
      eventtype = 'ffsc'
    }
    else {
      colhead = 'Contribution to Costs of Events'
      totolCount = tovdata.totalTa
      eventtype = 'cce'
    }
    const events = tovdata.events
    const events_list = events.slice(0, 3)
    return (
      <div className="eventdata">
        {user.userData.type === "hcpuser" &&
          <>
            <div className="col-sm-6 block-col">
              <h5> Fee for service and consultancy</h5>
              <div className="t-head">
                {tovdata.totalffs}
              </div>
              <div className="t-body">
                {events_list.map((event, index) => (
                  <EventList event={event} index={index} type="fsc" key={index} />
                ))
                }
              </div>
              <TovEventLink year={year} />
            </div>
          </>
        }

        <div className="col-sm-6 block-col">
          <h5> {colhead}</h5>
          <div className="t-head">
            {totolCount}
          </div>
          <div className="t-body">
            {events_list.map((event, index) => (
              <EventList event={event} index={index} type={eventtype} key={index} />
            ))

            }
          </div>
          <TovEventLink year={year} />
        </div>

        {
          user.userData.type === "hcouser" &&
          <>
            <div className="col-sm-6 block-col">
              <h5> Donations and Grants</h5>
              <div className="t-head">
                {tovdata.totaledg}
              </div>
              <div className="t-body">
                {events_list.map((event, index) => (
                  <EventList event={event} index={index} type="dg" key={index} />
                ))
                }
              </div>
              <TovEventLink year={year} />
            </div>
          </>
        }
        <div className="small align-right">
          * {year} yearly cumulative amounts
        </div>
      </div>
    )
  }
}

export default TovDetails
