import React, { useState, useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { fetchTovData } from '../../redux'
import { Container, Row, Col } from 'react-bootstrap'
import UserProfile from '../_user/UserProfile'
import TovDetails from './TovDetails'
import NeedClarification from './NeedClarification'
import Consent from './Consent'
// import{ConsentApi,fetchConsentdataSuccess} from './../../redux/consent/consentAction';

import '../css/Tov.css'

function Mytov() {
  const currentyear = new Date().getFullYear()
  const [year, setyear] = useState(currentyear)
  const [needModalShow, updateModalStatus] = useState(false)
  const [consentModalShow, updateConsentModalStatus] = useState(false)
  const userInfo = useSelector(state => state.user)
  
  // const profile = useSelector(state => state.consent)
  // const consent = useSelector(state => state.consent)
  const tov = useSelector(state => state.tov)
  const dispatch = useDispatch()

  useEffect(() => {
    if (Object.keys(tov.tovdata).length === 0) {
      dispatch(fetchTovData(userInfo.userData.codsid));
    }
   });

    

  const lastyear = currentyear - 1;
  const twoyear = currentyear - 2;

  const yearClickHandler = (year) => {
    setyear(year)
  }

  const c_class = (year === currentyear) ? "6 selected" : "3"
  const l_class = (year === lastyear) ? "6 selected" : "3"
  const t_class = (year === twoyear) ? "6 selected" : "3"

  return (
    <Container className="mytovpage">
      <Row>
        <Col sm={9}>
          <h1>My Transfer of value</h1>
          {tov.loading ?
            <p>Your Transfer of value data is loading.. </p>
            :
            <>
              {tov.error &&

                <div className="alert"> {tov.error} </div>
              }

              <ul className="row ctrls tov-cntrl">
                <li className="col-sm-4">
                  <div className="consent cntrl-clm" onClick={() => updateConsentModalStatus(true) } >
                    <span>Edit </span><br /> My Personal Preferences
                  </div>
                  <Consent year={year} show={consentModalShow} onHide={() => updateConsentModalStatus(false)} />
                </li>
                <li className="col-sm-4">
                  <div className="need cntrl-clm" onClick={() => updateModalStatus(true)}>
                    <span>Need</span><br />Clarification
                  </div>
                  <NeedClarification show={needModalShow} onHide={() => updateModalStatus(false)} year={year} />
                </li>
                <li className="col-sm-4">
                  <div className="print cntrl-clm">
                    <span>Print</span><br />My Transfer of Value
                  </div>
                </li>
              </ul>
              <div className="total-transfer-cont">
                <h4><b>Total Transfer of Value</b></h4>
              </div>
              <div className="year-cont">
                <div className={"year-cont-col col-md-" + t_class}>
                  <span className="img-left img"></span>
                  <span className="img-right img"></span>

                  {tov.tovdata && tov.tovdata[twoyear] &&
                    tov.tovdata[twoyear].total ?
                    <a href onClick={() => { yearClickHandler(twoyear) }}> {twoyear} | {tov.tovdata[twoyear].total}</a>
                    :
                    <p>{twoyear}</p>
                  }
                </div>
                <div className={"year-cont-col col-md-" + l_class}>
                  <span className="img-left img"></span>
                  <span className="img-right img"></span>
                  {
                    (tov.tovdata && tov.tovdata[lastyear]) &&
                      tov.tovdata[lastyear].total
                      ?
                      <a href onClick={() => { yearClickHandler(lastyear) }}> {lastyear} | {tov.tovdata[lastyear].total}</a>
                      :
                      <p> {lastyear} </p>
                  }
                </div>

                <div className={"year-cont-col col-md-" + c_class}>
                  <span className="img-left img"></span>
                  <span className="img-right img"></span>
                  {tov.tovdata && tov.tovdata[currentyear] &&
                    tov.tovdata[currentyear].total ?
                    <a href onClick={() => { yearClickHandler(currentyear) }}> {currentyear} | {tov.tovdata[currentyear].total}</a>
                    :
                    <p> {currentyear} </p>
                  }
                </div>
              </div>
              <TovDetails year={year} />
            </>
          }
        </Col>
        <Col sm={3}>
          <UserProfile />
        </Col>
      </Row>
    </Container>
  )
}

export default Mytov