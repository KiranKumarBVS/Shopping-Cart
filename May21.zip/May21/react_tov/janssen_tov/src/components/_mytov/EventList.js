import React from 'react'

function EventList(props) {
  const { event, index, type } = props
  const rowclass = index % 2 ? 't-row-even' : 't-row-odd'
  const related = event.HotelAmount + event.TravelAmount + event.OtherAmount

  return (
    <div className={"t-row " + rowclass} >
      <div className="event-head">{event.name}</div>
      <ul className="event-body">
        {
          (type === 'fsc') &&
          <>
            <li> Fees : {event.FfsAmount}</li>
            <li> Releated Expenses : {related} </li>
          </>
        }
        {
          (type === 'ffsc') &&
          <>
            <li className=""> Fees : {event.FfsAmount} </li>
            <li>Sponsorship agreements with HCOs / third parties appointed by HCOs to manage an Event : {event.SpoAmount} </li>
          </>
        }
        {
          (type === 'cce') &&
          <>
            <li> Registration Fees : {event.RegAmount}</li>
            <li> Travel & Accommodation : {event.ParticipantTaAmount} </li>
          </>
        }
        {
          (type === 'dg') &&
          <li> Donations and Grants to HCOs : {event.EdgAmount}</li>
        }
      </ul>
    </div>
  )
}

export default EventList
