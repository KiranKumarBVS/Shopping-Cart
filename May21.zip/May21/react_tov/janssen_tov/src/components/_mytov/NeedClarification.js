import React, { useState } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { FormGroup, FormLabel, FormControl, Button, FormCheck, Modal } from 'react-bootstrap'
import FormCheckLabel from 'react-bootstrap/FormCheckLabel'
import { needClarifyApi, fetchNeeddataFailure } from '../../redux/'

function NeedClarification(props) {
  const user = useSelector(state => state.user)
  const tov = useSelector(state => state.tov)
  const email_id = (user.userData.type === 'hcpuser') ? user.userData.email : ''
  const dispatch = useDispatch()
  const [state, setState] = useState({
    email: email_id,
    event: '',
    query: '',
    privacy: false,
    message: ''
  })

  const handleChange = (e) => {
    const { name, value } = e.target
    setState(prevState => ({
      ...prevState,
      [name]: value
    }))
  }

  const toggleChange = (e) => {
    setState(prevState => ({
      ...prevState,
      privacy: !prevState.privacy
    }))
  }

  const submitNeedClarification = e => {
    e.preventDefault();
    user ?
      dispatch(needClarifyApi())
    :
      dispatch(fetchNeeddataFailure())
    setState(prevState => ({
      ...prevState,
      email: email_id,
      event: '',
      query: '',
      privacy: false,
      message: `'Your query has been transferred to a customer service agent.
      You will be contacted by email or phone within (48 hours)
      Thank you for your commitment to enhancing transparency on interactions with the pharmaceutical industry.'`
    }))
  }
  
  // function handlerSend(e) {
  //   e.preventDefault();
  //   user ?
  //     dispatch(needClarifyApi())
  //   :
  //     dispatch(fetchNeeddataFailure())
  // }

  const year = props.year
  const nc_event = (tov.tovdata && tov.tovdata[year]) ? tov.tovdata[year].nc_events : [];
  const other = [{ value: 'Others' }]
  var nfc_event = [...nc_event, ...other]

  const closePopup = (e) => {
    setState(prevState => ({
      ...prevState,
      message: ''
    }))
    props.onHide()
  }

  return (
    <Modal show={props.show} onHide={closePopup}>
      <Modal.Header closeButton>
        <h3>Need Clarification</h3>
      </Modal.Header>
      <Modal.Body>
        <div>
          {
            (state.message) ?
              <div>
                {state.message}
              </div>
              :
              <>
                <div>
                  <p className="ncfdescl">If you have a query about the Transfer of Value data regarding an event, please select the relevant event from the drop down menu, and submit together with your query. A Janssen specialist will respond your request (within 48 hours)</p>
                </div>
                <form id="ncf" onSubmit={submitNeedClarification}>
                  <FormGroup controlId="email">
                    <FormLabel>
                      Your Email
                    </FormLabel>
                    <FormControl
                      type="email"
                      placeholder="Emails"
                      name="email"
                      onChange={handleChange}
                      value={state.email}
                      required
                    />
                  </FormGroup>
                  <FormGroup controlId="event">
                    <FormLabel>
                      Event
                    </FormLabel>
                    <FormControl
                      as="select"
                      value={state.event}
                      name="event"
                      onChange={handleChange}
                    >
                      {
                        nfc_event.map((option, index) => {
                          return (<option key={index} value={option.value}>{option.value}</option>)
                        })
                      }
                    </FormControl>

                  </FormGroup>
                  <FormGroup controlId="query">
                    <FormLabel>
                      Query
                    </FormLabel>
                    <textarea
                      value={state.query}
                      name="query"
                      onChange={handleChange}
                      required
                      rows="3"
                    />
                  </FormGroup>
                  <FormGroup>
                    <FormCheck
                      type="checkbox"
                      name="privacy"
                      checked={state.privacy}
                      onChange={toggleChange}
                      required
                      className="privacy"
                    />
                    <FormCheckLabel>
                      By submitting your information through this form, you agree that our Privacy Policy will govern such information. Because e-mail sent to and from this site may not be secure, you should take special care in deciding what information you send via e-mail to us. This form is not intended for the reporting of adverse events. If you have an adverse event that you wish to report please contact UK Drug Safety on 01494 567447 or at
                    </FormCheckLabel>
                  </FormGroup>
                  <Button className="ncfsubmit" type="submit" disabled={!state.privacy}>Send</Button>
                </form>
              </>
          }

        </div>
      </Modal.Body>
    </Modal>
  )
}

export default NeedClarification
