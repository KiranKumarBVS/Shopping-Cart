import React from 'react';
import ReactDOM from 'react-dom'
import EventHco from '../EventHco'
import { shallow, mount } from 'enzyme';
import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

configure({ adapter: new Adapter() });

const setUp = (props = {}) => {
    const wrapper = shallow(<EventHco {...props} />);
    return wrapper;
}

const findAttr = (wrapper, attr) => {
    const component = wrapper.find(`[data-testid="${attr}"]`);
    return component;
}

describe('< />', () => {
    describe('Have props <EventHco />', () => {
        let wrapper;
        beforeEach(() => {
            const props = {
                event: {
                    name : 'eventName'
                },
                index: '1'
            }
            wrapper = setUp(props);
        })
        it('should renders without errors', () => {
            const eventName = findAttr(wrapper, 'eventName')
            expect(eventName.length).toBe(1);
        })
        it('should renders without errors', () => {
            const eventName = findAttr(wrapper, 'nfctd')
            expect(eventName.text()).toEqual('Need Clarification');
            expect(eventName.length).toBe(1);
        })
        it('should renders without errors', () => {
            const changeClass = findAttr(wrapper, 'changeClass')
            expect(changeClass.length).toBe(1);
        })
    });
})