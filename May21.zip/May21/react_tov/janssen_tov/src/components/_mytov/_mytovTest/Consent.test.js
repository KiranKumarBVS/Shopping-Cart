import React from 'react';
import ReactDOM from 'react-dom'
import Consent from '../Consent'
import { shallow } from 'enzyme';
import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

configure({ adapter: new Adapter() });

it('it renders Header without crashing', () => {
    const Container = document.createElement("Modal");
    ReactDOM.render(<Consent />, Container)
})

it('renders submit button with custom text', () => {
    const wrapper = shallow(
        <Consent />
    )
    const button = wrapper.find('Button');
    expect(button).toHaveLength(1);
    expect(button.prop('type')).toEqual('submit');
    expect(button.find('Button').text()).toEqual('Continue')
});

describe('check title Edit My Personal Preferences', () => {
    it('check title Edit My Personal Preferences', () => {
        const about = shallow(
            <Consent />
        )
        expect(about.find('h3').text()).toEqual('Edit My Personal Preferences')
    })
})

describe('check title Edit My Personal Preferences', () => {
    it('check title Edit My Personal Preferences', () => {
        const about = shallow(
            <Consent />
        )
        expect(about.find('p').text()).toEqual(`If you have agreed to disclosure on an individual basis, your Transfer of Value data will be sent for public disclosure. This data will be published by the end of June each year.If you have not agreed to disclosure on an individual basis, your Transfer of Value data will be disclosed anonymously on an aggregate basis.Janssen respects your privacy rights and you can choose to withdraw your consent (opt out) at any time, without any negative impact. If you have any further questions please contact your Janssen representative or email disclosure@janssen.co.uk`)
    })
})

describe('Form Submit', () => {
    it('Form Submit', () => {
        const wrapper = shallow(
            <Consent />
        )
        const event = { preventDefault: () => { } }
        jest.spyOn(event, 'preventDefault')
        wrapper.find('form').simulate('submit', event)
        expect(event.preventDefault).toBeCalled()
    })
})
