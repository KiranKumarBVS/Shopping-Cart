import React from 'react';
import EventHcp from '../EventHcp'
import { shallow, mount } from 'enzyme';
import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

configure({ adapter: new Adapter() });

const setUp = (props = {}) => {
    const wrapper = shallow(<EventHcp {...props} />);
    return wrapper;
}

const findAttr = (wrapper, attr) => {
    const component = wrapper.find(`[data-testid="${attr}"]`);
    return component;
}

describe('<EventHcp />', () => {
    describe('Have props <EventHcp />', () => {
        let wrapper;
        beforeEach(() => {
            const props = {
                event: {
                    name: 'eventName'
                },
                index: '1'
            }
            wrapper = setUp(props);
        })

        it('should renders without errors', () => {
            const eventName = findAttr(wrapper, 'eventName')
            expect(eventName.length).toBe(1);
            expect(eventName.text()).toEqual('eventName')
        })
        it('should renders without errors', () => {
            const nfctd = findAttr(wrapper, 'nfctd')
            expect(nfctd.text()).toEqual('Need Clarification');
            expect(nfctd.length).toBe(1);
        })
        it('should renders without errors', () => {
            const eventName = findAttr(wrapper, 'RegAmount')
            expect(eventName.length).toBe(1);
        })
        it('should renders without errors', () => {
            const eventName = findAttr(wrapper, 'ParticipantTaAmount')
            expect(eventName.length).toBe(1);
        })
        it('should renders without errors', () => {
            const FfsAmount = findAttr(wrapper, 'FfsAmount')
            expect(FfsAmount.length).toBe(1);
        })
        it('should renders without errors', () => {
            const TravelAmount = findAttr(wrapper, 'TravelAmount')
            expect(TravelAmount.length).toBe(1);
        })
        it('should renders without errors', () => {
            const HotelAmount = findAttr(wrapper, 'HotelAmount')
            expect(HotelAmount.length).toBe(1);
        })
        it('should renders without errors', () => {
            const OtherAmount = findAttr(wrapper, 'OtherAmount')
            expect(OtherAmount.length).toBe(1);
        })
        it('should renders without errors', () => {
            const location = findAttr(wrapper, 'location')
            expect(location.length).toBe(1);
        })
        it('should renders without errors', () => {
            const country = findAttr(wrapper, 'country')
            expect(country.length).toBe(1);
        })
        it('should renders without errors', () => {
            const startDate = findAttr(wrapper, 'startDate')
            expect(startDate.length).toBe(1);
        })
        it('should renders without errors', () => {
            const endDate = findAttr(wrapper, 'endDate')
            expect(endDate.length).toBe(1);
        })
    });
})