import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Button, Modal } from "react-bootstrap";
import { ConsentApi } from "./../../redux/consent/consentAction";
import { UpdateConsentApi } from "./../../redux/consent/consentAction";

function Consent(props) {
  const profile = useSelector((state) => state.consent);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(ConsentApi());
  });

  const consentdata = profile.consentdata
    ? profile.consentdata.jj_tov_disclosure_current_year__c
    : "";
  const [consentvalue, updateConsent] = useState();
  const [defaultvalue, setupdateConsent] = useState();
  const [state, setState] = useState({
    radiobutton: false,
  });

  if (consentdata && consentvalue === undefined) {
    updateConsent(consentdata);
    setupdateConsent(consentdata);
  }
  function changeConsent(e) {
    updateConsent(e.target.value);
  }

  const closePopup = (e) => {
    setState((prevState) => ({
      ...prevState,
      message: "",
    }));
    props.onHide();
  };

  function handleSubmit(e) {
    e.preventDefault();
    dispatch(UpdateConsentApi(consentvalue));

    setState((prevState) => ({
      ...prevState,

      radiobutton: false,
      message: `'Your query has been transferred to a customer service agent.
      You will be contacted by email or phone within (48 hours)
      Thank you for your commitment to enhancing transparency on interactions with the pharmaceutical industry.'`,
    }));
  }

  return (
    <Modal show={props.show} onHide={closePopup}>
      <Modal.Header closeButton>
        <h3>Edit My Personal Preferences</h3>
      </Modal.Header>
      <Modal.Body>
        <div>
          <form
            onSubmit={handleSubmit}
            id="consentform"
            className="consen-form"
          >
            {state.message ? (
              <div>{state.message}</div>
            ) : (
              <>
                <div className="footer-text">
                  <p>
                    If you have agreed to disclosure on an individual basis,
                    your Transfer of Value data will be sent for public
                    disclosure. This data will be published by the end of June
                    each year.
                    <br />
                    If you have not agreed to disclosure on an individual basis,
                    your Transfer of Value data will be disclosed anonymously on
                    an aggregate basis.
                    <br />
                    Janssen respects your privacy rights and you can choose to
                    withdraw your consent (opt out) at any time, without any
                    negative impact. If you have any further questions please
                    contact your Janssen representative or email
                    disclosure@janssen.co.uk
                  </p>

                  <div id="edit-tov-privacy-checkbox" className="form-radios ">
                    <div className="form-item form-type-radio form-item-tov-privacy-checkbox">
                      <label
                        className="option"
                        for="edit-tov-privacy-checkbox-individual"
                      >
                        <input
                          className=" form-radio"
                          type="radio"
                          name="Profilepreference"
                          value="Individual"
                          onChange={changeConsent}
                          checked={consentvalue === "Individual"}
                        />
                        <span id="IAgree">
                          I agree to the individual publication of my personal
                          data in the open reporting
                        </span>{" "}
                      </label>
                    </div>

                    <div className="form-item form-type-radio form-item-tov-privacy-checkbox">
                      <label
                        className="option"
                        for="edit-tov-privacy-checkbox-aggregate"
                      >
                        <input
                          className=" form-radio"
                          type="radio"
                          id="edit-tov-privacy-checkbox-aggregate"
                          name="Profilepreference"
                          value="Aggregate"
                          onChange={changeConsent}
                          checked={consentvalue === "Aggregate"}
                        />
                        <span id="IDAgree">
                          I do not agree with individual publication in the open
                          reporting
                        </span>{" "}
                      </label>
                    </div>
                  </div>
                </div>
                {defaultvalue !== consentvalue ? (
                  <Button type="submit" className="consent-btn">
                    Continue
                  </Button>
                ) : (
                  <Button type="submit" disabled className="consent-btn">
                    Continue
                  </Button>
                )}
              </>
            )}
          </form>
        </div>
      </Modal.Body>
    </Modal>
  );
}

export default Consent;
