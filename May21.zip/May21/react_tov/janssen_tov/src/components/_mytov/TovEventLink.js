import React, { useState } from 'react'
import TovEventList from './TovEventList'

function TovEventLink(props) {
  const [eventShow, updateEventshow] = useState(false)
  const { year } = props
  return (
    <div className="eventViewlink">
      <a href className="viewmore" onClick={() => updateEventshow(true)}>VIEW MORE DETAILS/EVENTS</a>
      <TovEventList year={year} show={eventShow} onHide={() => updateEventshow(false)} />
    </div>
  )
}

export default TovEventLink
