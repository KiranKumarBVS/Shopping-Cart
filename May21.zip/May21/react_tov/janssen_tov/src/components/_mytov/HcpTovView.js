import React from 'react'
import { useSelector } from 'react-redux'
import EventHcp from './EventHcp'

function HcpTovView(props) {
  const year = props.year
  const tov = useSelector(state => state.tov)
  const tovdata = tov.tovdata[year]
  const events = tovdata.events

  return (
    <div className="listview">
      <table className="tovtable">
        <tbody>
          <tr className="tovTotalCost">
            <td colSpan="2"></td>
            <td colSpan="2"> {tovdata.totalTa} *</td>
            <td colSpan="4">{tovdata.totalffs} *</td>
            <td colSpan="4"></td>
          </tr>
          <tr className="trodd mainHead">
            <td></td>
            <td className="eventHead"></td>
            <td colSpan="2">Contribution to costs of Events</td>
            <td colSpan="4">Fee for service and consultancy</td>
            <td colSpan="4">Event information</td>
          </tr>
          <tr className="treven">
            <td rowSpan="2">CURRENCY FIELD</td>
            <td rowSpan="2" className="eventHead no-top-border">Event Name</td>
            <td rowSpan="2">Registration Fees</td>
            <td rowSpan="2">Travel & Accommodation</td>
            <td rowSpan="2">Fees</td>
            <td colSpan="3">Related expenses agreed in the fee for service or consultancy contract, including travel & accommodation relevant to the contract</td>
            <td rowSpan="2"> Location</td>
            <td rowSpan="2">Country</td>
            <td rowSpan="2">Start Date</td>
            <td rowSpan="2">End Date</td>
          </tr>
          <tr className="treven">
            <td>Total Travel Cost</td>
            <td>Total Hotel Cost</td>
            <td>Total Other</td>
          </tr>
          {events.map((event, index) => (
            <EventHcp event={event} index={index} key={index} />
          ))
          }
        </tbody>
      </table>
    </div>
  )
}

export default HcpTovView
