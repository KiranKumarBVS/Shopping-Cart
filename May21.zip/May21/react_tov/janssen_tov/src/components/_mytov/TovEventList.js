import React from 'react'
import { Modal } from 'react-bootstrap'
import { useSelector } from 'react-redux'
import HcoTovView from './HcoTovView'
import HcpTovView from './HcpTovView'

function TovEventList(props) {
  const year = props.year
  const user = useSelector(state => state.user)

  return (
    <Modal {...props}>
      <Modal.Header closeButton></Modal.Header>
      <Modal.Body>
        {
          (user.userData.type === "hcouser") ?
            <>
              <HcoTovView year={year} />
            </>
            :
            <>
              <HcpTovView year={year} />
            </>
        }
      </Modal.Body>
    </Modal>
  )
}

export default TovEventList
