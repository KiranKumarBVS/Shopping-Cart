import React from 'react'

function EventHcp(props) {
  const event = props.event
  const classname = props.index % 2 ? 'treven' : 'trodd'

  return (
    <tr className={classname}>
      <td className="nfctd" data-testid="nfctd">Need Clarification</td>
      <td className="eventHead" data-testid="eventName">{event.name}</td>
      <td data-testid="RegAmount">{event.RegAmount}</td>
      <td data-testid="ParticipantTaAmount"> {event.ParticipantTaAmount} </td>
      <td data-testid="FfsAmount">{event.FfsAmount}</td>
      <td data-testid="TravelAmount">{event.TravelAmount}</td>
      <td data-testid="HotelAmount">{event.HotelAmount}</td>
      <td data-testid="OtherAmount">{event.OtherAmount}</td>
      <td data-testid="location">{event.location}</td>
      <td data-testid="country">{event.country} </td>
      <td data-testid="startDate">{event.startDate}</td>
      <td data-testid="endDate">{event.endDate}</td>
    </tr>
  )
}

export default EventHcp
