import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faUserTie, faSignOutAlt } from '@fortawesome/free-solid-svg-icons'
import { logout } from '../../redux'


function UserProfile() {
  const userinfo = useSelector(state => state.user)
  const user = userinfo.userData
  const dispatch = useDispatch()

  function tovlogout(e) {
    e.preventDefault();
    dispatch(logout())
  }

  return (
    <section className="sidebar-cont">
      <ul>
        <li className="user">
          <span className="iconspan">
            <FontAwesomeIcon icon={faUserTie} />
          </span>
          {(user.type === 'hcouser')
            ?
            <>
              {user.name} <br />
              <span className="address"> {user.address} <br />
                {user.city} <br />
                {user.province} - {user.postal}
              </span>
            </>
            :
            <>
              {user.fname} {user.lname}
            </>
          }
        </li>
        <li className="logout">
          <span className="iconspan">
            <FontAwesomeIcon icon={faSignOutAlt} />
          </span>
          <a href onClick={(e) => { tovlogout(e) }}>Logout</a>
        </li>
      </ul>
    </section>
  )
}

export default UserProfile
