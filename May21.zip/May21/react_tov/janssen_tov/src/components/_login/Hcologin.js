import React, { useState } from 'react'
import { Jumbotron, FormGroup, FormLabel, FormControl, Button } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faLock } from '@fortawesome/free-solid-svg-icons';
import { useSelector, useDispatch } from 'react-redux'
import  { hcoUserLogin, fetchUserdataFailure } from '../../redux'

function Hcologin() {
  const [hcoid, setHcoid] = useState('')
  const userInfo = useSelector(state => state.user)
  const dispatch = useDispatch()
  function changeHconumber(e) {
    setHcoid(e.target.value);
  }

  function handleSubmit(e) {
    e.preventDefault();
    const errorMsg = {
      error: 'Please enter a HCO UNIQUE Number',
      type: 'hco'
    }
    hcoid ?
      dispatch(hcoUserLogin(hcoid))
    :
      dispatch(fetchUserdataFailure(errorMsg))
  }

  return (
    <div>
      <h4> <b>Healthcare Organization Login</b></h4>
      <Jumbotron>
        {userInfo.error && userInfo.error_type === 'hco' && 
          <div className="alert alert-danger"> { userInfo.error }</div>
        }
        <p>If you are interested in viewing Transfers of Value made to your Healthcare organisation, you will need to type the unique code into the box on the right. You will find the unique code in your contract documentation.</p>
        <form id='hcologin' className="loginform" onSubmit={handleSubmit}>
          <FormGroup controlId="hconumber">
            <FormLabel>
              <FontAwesomeIcon icon={faLock}/>
            </FormLabel>
            <FormControl
              type="textfield"
              value={hcoid}
              name="hcoid"
              placeholder="HCO UNIQUE NUMBER"
              onChange={changeHconumber}></FormControl>
          </FormGroup>
          <Button value="Login" type="submit" className="form-submit btn btn-submit btn-xs login-btn">Login</Button>
        </form>
      </Jumbotron>
    </div>
  )
}

export default Hcologin
