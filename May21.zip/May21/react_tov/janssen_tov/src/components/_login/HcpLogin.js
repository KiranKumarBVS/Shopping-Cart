import React, { useState } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { Jumbotron, Row, FormGroup, FormLabel, FormControl , Col, Button } from 'react-bootstrap'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faUserTie, faLock } from '@fortawesome/free-solid-svg-icons'
import  { hcpUserLogin, fetchUserdataFailure } from '../../redux'
import janssenlogo from '../../Images/janssen-logo.png'

function HcpLogin() {
  const [state, setLoginState] = useState({
    email: '',
    password: ''
  })
  const user = useSelector(state => state.user)
  const dispatch = useDispatch()
  const forget_link = process.env.REACT_APP_HCP_FORGET_URL
  const register_link = process.env.REACT_APP_HCP_REGISTER_URL
  const handleChange = e => {
    const {name , value} = e.target
    setLoginState( prevState => ({
        ...prevState,
        [name] : value
    }))
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (state.email === '' || state.password === '') {
      const errorMsg = {
        error: 'Please complete all mandatory fields',
        type: 'hcp'
      }
      dispatch(fetchUserdataFailure(errorMsg))
    }
    else {
      dispatch(hcpUserLogin(state.email, state.password))
    }
  }

  return (
    <div>
      <h4><b>Healthcare Professional Login</b></h4>
      <Jumbotron className="sso-login-form">
        <Row>
          <h3 className="brandjanrain col-md-6"><b>OneWeb</b> Accesss</h3>
          <a href="/" className="brand col-md-6"><img src={janssenlogo} alt="logo" /></a>
        </Row>
        {user.error && user.error_type === 'hcp' && 
          <div className="alert alert-danger"> { user.error }</div>
        }
        <form id="hcplogin" className="loginform" onSubmit={handleSubmit} >
          <FormGroup controlId="email">
            <FormLabel>
              <FontAwesomeIcon icon={faUserTie} />
            </FormLabel>
            <FormControl 
              type="email"
              placeholder="Emails"
              name="email"
              onChange={handleChange}
              value={state.email}
            />
          </FormGroup>
          <FormGroup controlId="password">
            <FormLabel>
              <FontAwesomeIcon icon={faLock} />
            </FormLabel>
              <FormControl 
                type="password"
                placeholder="Password"
                value={state.password}
                name="password"
                onChange={handleChange}
              ></FormControl>
            </FormGroup>
            <Col sm={12}>
              <Col sm={8} className="sso-links">
                <a href={`${register_link}`} className="register">Need to Register?</a>
                <a href={`${forget_link}`} className="forgot-pass">Forget Password?</a>
              </Col>
              <Col sm={4} className="loginbtn">
                <Button value="Login" type="submit" className="form-submit btn btn-submit btn-xs login-btn">Login</Button>
              </Col>
            </Col>
        </form>
      </Jumbotron>
    </div>
  )
}

export default HcpLogin
