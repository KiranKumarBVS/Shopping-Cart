import React from 'react'
import { Container, Row, Col } from 'react-bootstrap'
import HcpLogin from './HcpLogin'
import Hcologin from './Hcologin'

import '../css/Login.css'

function Login() {
  return (
    <Container className="loginpage">
      <Row>
        <Col sm={6} className="healthcare-professional-login healthcare-login">
          <HcpLogin/>
        </Col>
        <Col sm={6} className="healthcare-Organization-login healthcare-login">
          <Hcologin/>
        </Col>
      </Row>
    </Container>
  )
}

export default Login
