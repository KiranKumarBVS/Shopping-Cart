import { Route, Redirect } from 'react-router-dom'
import React from 'react'
import { useSelector } from 'react-redux'

const TovPrivateRoute = ({ component: Component, ...rest }) => {
  const user = useSelector(state => state.user)

  return (
    <Route {...rest} render={props => (
      user.isLogin === true ?
        <Component {...props} />
        : <Redirect to="/" />
    )} />
  );
};

export default TovPrivateRoute;

