import React from 'react'
import { Redirect, Route } from 'react-router-dom'
import { useSelector} from 'react-redux'

const TovRoute = ({ component: Component, ...rest }) =>  {
  const user = useSelector(state => state.user)

  return (
    <Route {...rest} render={props => (
      user.isLogin === false ?
          <Component {...props} />
        : <Redirect to="/my-tov" />
    )} />
  );
}

export default TovRoute