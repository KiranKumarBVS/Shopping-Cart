import React from 'react';
import ReactDOM from 'react-dom'
import Footer from '../Footer'
import { shallow } from 'enzyme';
import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

configure({ adapter: new Adapter() });

it('it renders Footer without crashing',()=>{
  const Container = document.createElement("Container");
  ReactDOM.render(<Footer></Footer>, Container)
})

describe('check page-title', () => {
  it('check page-title"', () => {
    const about = shallow(
      <Footer />
    )
    expect(about.find('p').text()).toEqual(`This site is intended for audiences in Europe, the Middle East and Africa - Last updated on 03 February 2020. © Janssen Pharmaceutica N.V. 2020 - This site is published by Janssen Pharmaceutica N.V., which is solely responsible for its content.`)
  })
})