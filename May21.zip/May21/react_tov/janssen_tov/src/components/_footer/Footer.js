import React from 'react'
import { Container, Row, Col } from 'react-bootstrap'
import logo from '../../Images/logo.png'

function Footer() {
  return (
    <Container>
      <footer>
        <Row>
          <Col sm={12}>
            <nav>
              <ul className="footerlink">
                <li><a href="http://uat.janssentransferofvalue.com/gb_en/privacy-policy">Privacy Policy</a></li>
                <li><a href="http://uat.janssentransferofvalue.com/gb_en/legal-notice">Legal Notice</a></li>
                <li><a href="http://uat.janssentransferofvalue.com/gb_en/cookie-policy">Cookie Policy</a></li>
              </ul>
            </nav>
          </Col>

          <Col sm={7}>
            <p>This site is intended for audiences in Europe, the Middle East and Africa - Last updated on 03 February 2020.
© Janssen Pharmaceutica N.V. 2020 - This site is published by Janssen Pharmaceutica N.V., which is solely responsible for its content.</p>
          </Col>
          <Col sm={5} className="jnj-brand">
            <a href="/">
              <img src={logo} alt="Logo" />
            </a>
          </Col>
        </Row>
      </footer>
    </Container>
  )
}

export default Footer
