import React from 'react';
import ReactDOM from 'react-dom'
import Header from '../Header'
import { shallow } from 'enzyme';
import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

configure({ adapter: new Adapter() });

it('it renders Header without crashing',()=>{
  const Container = document.createElement("Container");
  ReactDOM.render(<Header />, Container)
})

