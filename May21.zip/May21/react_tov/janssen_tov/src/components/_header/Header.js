import React from 'react'
import logo from '../../Images/logo.png'
import { Container, Row } from 'react-bootstrap'

function Header() {
  return (
    <Container>
      <Row>
        <header className="navbar-header">
          <a className="navbar-brand" href="/">
            <img src={logo} alt="Home" />
          </a>
        </header>
      </Row>
    </Container>
  )
}

export default Header
