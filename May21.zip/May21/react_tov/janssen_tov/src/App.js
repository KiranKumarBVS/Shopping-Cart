import React from 'react';
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom'
import { Provider } from 'react-redux'
import store from './redux/store'
import Header from './components/_header/Header';
import Footer from './components/_footer/Footer';
import Login from './components/_login/Login';
import TovRoute from './components/_routing/TovRoute';
import TovPrivateRoute from './components/_routing/TovPrivateRoute';
import Mytov from './components/_mytov/Mytov';

import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const Notfound = () => <h1>Not Found</h1>
  return (
    <Provider store={store}>
      <div className="App">
        <Router>
          <Header/>
          <Switch>
            <TovRoute path ="/" exact type="public" component={Login} />
            <TovPrivateRoute path="/my-tov" exact component={Mytov} />
            <Route path="*" component={Notfound} />
          </Switch>
          <Footer/>
        </Router>
      </div>
    </Provider>
  );
}

export default App;
